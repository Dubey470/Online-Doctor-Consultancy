package com.example.Doctor.Consultancy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorConsultancyApplicationTests {

	@Test
	void contextLoads() {
	}

}
